/**
 * KARTA API Routes
 * All endpoints in one file for hackathon clarity
 * In production: split into separate route modules
 */

import type { FastifyInstance } from 'fastify';
import { z }                    from 'zod';

import { authMiddleware }        from '../middleware/auth';
import * as AuthSvc              from '../services/auth';
import * as MRVSvc               from '../services/mrv';
import * as PaySvc               from '../services/payments';
import { generateZKProof }       from '../services/zk';
import { verifyExistingProof }   from '../services/zk';
import { retireCredits }         from '../services/solana';
import { solanaHealthCheck }     from '../services/solana';
import { query }                 from '../db/pool';
import { logger }                from '../utils/logger';
import {
  SendOTPSchema, VerifyOTPSchema,
  CreateProjectSchema, CreateListingSchema,
  CreatePaymentSchema, RetireCreditsSchema,
} from '../types/schemas';

export async function registerRoutes(app: FastifyInstance): Promise<void> {

  // ──────────────────────────────────────────────────
  // HEALTH
  // ──────────────────────────────────────────────────
  app.get('/health', async () => {
    const solana = await solanaHealthCheck();
    return {
      status:    'ok',
      version:   '1.0.0',
      timestamp: new Date().toISOString(),
      services: {
        database: 'ok',
        solana:   solana.ok ? 'ok' : 'degraded',
        solanaSlot: solana.slot,
      },
    };
  });

  // ──────────────────────────────────────────────────
  // AUTH
  // ──────────────────────────────────────────────────
  app.post('/api/v1/auth/otp/send', async (req, reply) => {
    const body = SendOTPSchema.parse(req.body);
    const res  = await AuthSvc.sendOTP(body.phoneNumber, body.countryCode);
    return reply.status(200).send(res);
  });

  app.post('/api/v1/auth/otp/verify', async (req, reply) => {
    const body = VerifyOTPSchema.parse(req.body);
    const res  = await AuthSvc.verifyOTPAndIssueTokens(
      body.phoneNumber,
      body.countryCode,
      body.otp,
      body.deviceFingerprint
    );
    return reply.status(200).send(res);
  });

  app.post('/api/v1/auth/token/refresh', async (req, reply) => {
    const { refreshToken } = req.body as { refreshToken: string };
    if (!refreshToken) return reply.status(400).send({ error: 'refreshToken required' });
    const res = await AuthSvc.refreshAccessToken(refreshToken);
    return reply.status(200).send(res);
  });

  app.get('/api/v1/auth/me', { preHandler: authMiddleware }, async (req, reply) => {
    const user = await AuthSvc.getUserById(req.user!.sub);
    if (!user) return reply.status(404).send({ error: 'User not found' });
    return reply.send(user);
  });

  // ──────────────────────────────────────────────────
  // PROJECTS
  // ──────────────────────────────────────────────────
  app.post('/api/v1/projects', { preHandler: authMiddleware }, async (req, reply) => {
    const body     = CreateProjectSchema.parse(req.body);
    const userId   = req.user!.sub;

    // Insert project with PostGIS point
    const result = await query(
      `INSERT INTO projects
       (user_id, entity_type, name, location, area_ha, metadata, status)
       VALUES ($1,$2,$3,ST_SetSRID(ST_MakePoint($4,$5),4326),$6,$7,'submitted')
       RETURNING id, entity_type, name, status, created_at`,
      [
        userId,
        body.entityType,
        body.name,
        body.location.lng,
        body.location.lat,
        body.areaHa || null,
        JSON.stringify(body.metadata),
      ]
    );

    const project = result.rows[0];

    // Trigger MRV pipeline asynchronously
    MRVSvc.runMRVPipeline(project.id).catch(err =>
      logger.error('Async MRV pipeline error', { projectId: project.id, error: err.message })
    );

    return reply.status(201).send({
      project,
      message: 'Project submitted. MRV pipeline started.',
    });
  });

  app.get('/api/v1/projects', { preHandler: authMiddleware }, async (req, reply) => {
    const { page = '1', limit = '20', status } = req.query as any;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const whereClause = status ? `AND p.status = '${status}'` : '';

    const result = await query(
      `SELECT p.id, p.entity_type, p.name, p.status, p.area_ha, p.created_at,
              ST_Y(p.location::geometry) as lat, ST_X(p.location::geometry) as lng,
              v.co2e_estimated, v.confidence_score, v.grade,
              z.proof_hash
       FROM projects p
       LEFT JOIN ai_verifications v ON v.project_id = p.id
       LEFT JOIN zk_proofs z ON z.project_id = p.id
       WHERE p.user_id = $1 ${whereClause}
       ORDER BY p.created_at DESC
       LIMIT $2 OFFSET $3`,
      [req.user!.sub, parseInt(limit), offset]
    );

    return reply.send({ projects: result.rows, page: parseInt(page), limit: parseInt(limit) });
  });

  app.get('/api/v1/projects/:id', { preHandler: authMiddleware }, async (req, reply) => {
    const { id } = req.params as { id: string };

    const result = await query(
      `SELECT p.*, u.name as farmer_name,
              ST_Y(p.location::geometry) as lat, ST_X(p.location::geometry) as lng,
              v.co2e_estimated, v.co2e_lower_bound, v.co2e_upper_bound,
              v.confidence_score, v.fraud_risk, v.activity_detection,
              v.satellite_consistency, v.data_quality, v.methodology_match,
              v.permanence_score, v.grade, v.price_min_inr, v.price_max_inr,
              z.proof_hash, z.solana_anchor_tx, z.public_signals,
              z.verification_status as zk_status,
              cc.mint_address, cc.amount_co2e, cc.solana_mint_tx
       FROM projects p
       JOIN users u ON u.id = p.user_id
       LEFT JOIN ai_verifications v ON v.project_id = p.id
       LEFT JOIN zk_proofs z ON z.project_id = p.id
       LEFT JOIN carbon_credits cc ON cc.project_id = p.id
       WHERE p.id = $1 AND p.user_id = $2
       ORDER BY v.created_at DESC, z.generated_at DESC
       LIMIT 1`,
      [id, req.user!.sub]
    );

    if (result.rows.length === 0) return reply.status(404).send({ error: 'Project not found' });

    return reply.send(result.rows[0]);
  });

  // Re-trigger MRV pipeline manually
  app.post('/api/v1/projects/:id/analyze', { preHandler: authMiddleware }, async (req, reply) => {
    const { id } = req.params as { id: string };
    MRVSvc.runMRVPipeline(id).catch(err =>
      logger.error('Manual MRV trigger error', { projectId: id, error: err.message })
    );
    return reply.send({ message: 'MRV pipeline triggered', projectId: id });
  });

  // Mint carbon credit token
  app.post('/api/v1/projects/:id/mint', { preHandler: authMiddleware }, async (req, reply) => {
    const { id }   = req.params as { id: string };
    const { listForSale = true, listPriceInr } = req.body as any;

    const result = await MRVSvc.mintProjectCredit(id, listForSale, listPriceInr);
    return reply.status(201).send(result);
  });

  // ──────────────────────────────────────────────────
  // ZK PROOF
  // ──────────────────────────────────────────────────
  app.get('/api/v1/proofs/:hash/verify', async (req, reply) => {
    const { hash } = req.params as { hash: string };
    const result   = await verifyExistingProof(hash);
    return reply.send(result);
  });

  app.get('/api/v1/projects/:id/proof', { preHandler: authMiddleware }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const result = await query(
      `SELECT proof_hash, public_signals, solana_anchor_tx, anchor_slot,
              verification_status, circuit_version, generated_at
       FROM zk_proofs WHERE project_id = $1 ORDER BY generated_at DESC LIMIT 1`,
      [id]
    );
    if (result.rows.length === 0) return reply.status(404).send({ error: 'Proof not found' });
    return reply.send(result.rows[0]);
  });

  // ──────────────────────────────────────────────────
  // MARKETPLACE
  // ──────────────────────────────────────────────────
  app.get('/api/v1/marketplace', async (req, reply) => {
    const {
      page = '1', limit = '20',
      grade, entityType, minPrice, maxPrice,
      sortBy = 'created_at', sortDir = 'desc',
    } = req.query as any;

    const offset   = (parseInt(page) - 1) * parseInt(limit);
    const filters: string[] = ["ml.status = 'active'"];
    const params:  any[]    = [];
    let   pIdx             = 1;

    if (grade)      { filters.push(`cc.grade = $${pIdx++}`);             params.push(grade); }
    if (entityType) { filters.push(`p.entity_type = $${pIdx++}`);        params.push(entityType); }
    if (minPrice)   { filters.push(`ml.unit_price_inr >= $${pIdx++}`);   params.push(parseFloat(minPrice)); }
    if (maxPrice)   { filters.push(`ml.unit_price_inr <= $${pIdx++}`);   params.push(parseFloat(maxPrice)); }

    const where = filters.length ? 'WHERE ' + filters.join(' AND ') : '';

    const allowedSort = ['created_at', 'unit_price_inr', 'confidence_score', 'co2e_estimated'];
    const safeSort    = allowedSort.includes(sortBy) ? sortBy : 'ml.created_at';

    params.push(parseInt(limit), offset);

    const result = await query(
      `SELECT ml.id as listing_id, ml.quantity, ml.unit_price_inr, ml.created_at,
              cc.id as credit_id, cc.grade, cc.methodology, cc.vintage_year,
              cc.mint_address, cc.amount_co2e,
              p.id as project_id, p.entity_type, p.name as project_name,
              p.area_ha,
              ST_Y(p.location::geometry) as lat, ST_X(p.location::geometry) as lng,
              v.co2e_estimated, v.confidence_score, v.fraud_risk,
              z.proof_hash,
              u.name as seller_name, u.organisation
       FROM marketplace_listings ml
       JOIN carbon_credits cc ON cc.id = ml.credit_id
       JOIN projects p ON p.id = cc.project_id
       LEFT JOIN ai_verifications v ON v.project_id = p.id
       LEFT JOIN zk_proofs z ON z.project_id = p.id
       JOIN users u ON u.id = ml.seller_id
       ${where}
       ORDER BY ${safeSort} ${sortDir === 'asc' ? 'ASC' : 'DESC'}
       LIMIT $${pIdx++} OFFSET $${pIdx}`,
      params
    );

    return reply.send({
      listings: result.rows,
      page:     parseInt(page),
      limit:    parseInt(limit),
    });
  });

  // Live price ticker
  app.get('/api/v1/marketplace/ticker', async (_req, reply) => {
    const result = await query(
      `SELECT grade,
              AVG(unit_price_inr)::numeric(10,2) as avg_price,
              COUNT(*) as listing_count,
              SUM(quantity) as total_volume
       FROM marketplace_listings ml
       JOIN carbon_credits cc ON cc.id = ml.credit_id
       WHERE ml.status = 'active' AND ml.created_at > NOW() - INTERVAL '7 days'
       GROUP BY grade ORDER BY grade`
    );

    return reply.send({
      ticker:    result.rows,
      updatedAt: new Date().toISOString(),
    });
  });

  app.post('/api/v1/marketplace/listings', { preHandler: authMiddleware }, async (req, reply) => {
    const body = CreateListingSchema.parse(req.body);

    // Verify credit belongs to user
    const creditRes = await query(
      `SELECT cc.id FROM carbon_credits cc
       JOIN projects p ON p.id = cc.project_id
       WHERE cc.id = $1 AND p.user_id = $2 AND cc.status = 'minted'`,
      [body.creditId, req.user!.sub]
    );
    if (creditRes.rows.length === 0) {
      return reply.status(403).send({ error: 'Credit not found or not owned by you' });
    }

    const result = await query(
      `INSERT INTO marketplace_listings (seller_id, credit_id, quantity, unit_price_inr)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [req.user!.sub, body.creditId, body.quantity, body.unitPriceInr]
    );

    await query(`UPDATE carbon_credits SET status = 'listed' WHERE id = $1`, [body.creditId]);

    return reply.status(201).send(result.rows[0]);
  });

  // ──────────────────────────────────────────────────
  // PAYMENTS
  // ──────────────────────────────────────────────────
  app.post('/api/v1/payments/checkout', { preHandler: authMiddleware }, async (req, reply) => {
    const body = CreatePaymentSchema.parse(req.body);
    const res  = await PaySvc.createPaymentIntent(
      req.user!.sub,
      body.listingId,
      body.quantity
    );
    return reply.status(201).send(res);
  });

  app.get('/api/v1/payments/:sessionId', { preHandler: authMiddleware }, async (req, reply) => {
    const { sessionId } = req.params as { sessionId: string };
    const status = await PaySvc.getPaymentStatus(sessionId, req.user!.sub);
    if (!status) return reply.status(404).send({ error: 'Payment not found' });
    return reply.send(status);
  });

  // Dodo webhook (no auth — Dodo calls this directly)
  app.post('/api/v1/payments/webhook', async (req, reply) => {
    const rawBody  = JSON.stringify(req.body);
    const sig      = (req.headers['x-dodo-signature'] as string) ||
                     (req.headers['x-webhook-signature'] as string) || '';
    try {
      const result = await PaySvc.handleWebhook(rawBody, sig);
      return reply.status(200).send(result);
    } catch (err: any) {
      logger.error('Webhook error', { error: err.message });
      return reply.status(400).send({ error: err.message });
    }
  });

  // DEV: simulate payment success
  app.post('/api/v1/payments/:sessionId/simulate-success', async (req, reply) => {
    if (process.env.NODE_ENV === 'production') {
      return reply.status(404).send({ error: 'Not found' });
    }
    const { sessionId } = req.params as { sessionId: string };
    await PaySvc.simulatePaymentSuccess(sessionId);
    return reply.send({ message: 'Payment simulated as success', sessionId });
  });

  // ──────────────────────────────────────────────────
  // PORTFOLIO
  // ──────────────────────────────────────────────────
  app.get('/api/v1/portfolio', { preHandler: authMiddleware }, async (req, reply) => {
    const result = await query(
      `SELECT up.*, cc.grade, cc.methodology, cc.vintage_year, cc.mint_address,
              cc.amount_co2e, p.name as project_name, p.entity_type,
              ml.unit_price_inr as list_price,
              v.confidence_score
       FROM user_portfolio up
       JOIN carbon_credits cc ON cc.id = up.credit_id
       JOIN projects p ON p.id = cc.project_id
       LEFT JOIN marketplace_listings ml ON ml.credit_id = cc.id AND ml.status = 'active'
       LEFT JOIN ai_verifications v ON v.project_id = p.id
       WHERE up.user_id = $1 AND up.retired_at IS NULL
       ORDER BY up.purchased_at DESC`,
      [req.user!.sub]
    );

    // Portfolio summary
    const totals = result.rows.reduce(
      (acc, row) => ({
        totalCo2e:  acc.totalCo2e  + parseFloat(row.quantity),
        totalValue: acc.totalValue + parseFloat(row.quantity) * parseFloat(row.list_price || row.buy_price),
      }),
      { totalCo2e: 0, totalValue: 0 }
    );

    return reply.send({ holdings: result.rows, summary: totals });
  });

  // ──────────────────────────────────────────────────
  // RETIRE CREDITS
  // ──────────────────────────────────────────────────
  app.post('/api/v1/credits/retire', { preHandler: authMiddleware }, async (req, reply) => {
    const body = RetireCreditsSchema.parse(req.body);

    // Verify ownership
    const holdingRes = await query(
      `SELECT up.*, cc.mint_address, cc.amount_co2e,
              p.id as project_id, p.name as project_name
       FROM user_portfolio up
       JOIN carbon_credits cc ON cc.id = up.credit_id
       JOIN projects p ON p.id = cc.project_id
       WHERE up.credit_id = $1 AND up.user_id = $2 AND up.retired_at IS NULL`,
      [body.creditId, req.user!.sub]
    );

    if (holdingRes.rows.length === 0) {
      return reply.status(403).send({ error: 'Credit not found in your portfolio' });
    }

    const holding    = holdingRes.rows[0];
    const userResult = await query(`SELECT wallet_address FROM users WHERE id = $1`, [req.user!.sub]);
    const wallet     = userResult.rows[0]?.wallet_address || 'devnet_wallet';

    const retireResult = await retireCredits(
      holding.mint_address   || 'mock_mint',
      wallet,
      body.quantity,
      wallet,
      body.organisationName  || 'Unknown',
      holding.project_id
    );

    // Record retirement
    await query(
      `INSERT INTO retirement_certificates
       (credit_id, retiring_user_id, organisation_name, esg_reference,
        amount_co2e, burn_tx_hash, nft_mint_address)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [
        body.creditId,
        req.user!.sub,
        body.organisationName,
        body.esgReference,
        body.quantity,
        retireResult.burnTxHash,
        retireResult.certNFTMint,
      ]
    );

    await query(
      `UPDATE user_portfolio SET retired_at = NOW() WHERE credit_id = $1 AND user_id = $2`,
      [body.creditId, req.user!.sub]
    );

    await query(
      `UPDATE carbon_credits SET status = 'retired', retired_at = NOW() WHERE id = $1`,
      [body.creditId]
    );

    return reply.send({
      message:      'Credits retired',
      burnTxHash:   retireResult.burnTxHash,
      certNFTMint:  retireResult.certNFTMint,
      slot:         retireResult.slot,
      quantity:     body.quantity,
      certUrl:      `https://certs.karta.pro/${retireResult.burnTxHash}`,
    });
  });

  // Get retirement certificates
  app.get('/api/v1/certificates', { preHandler: authMiddleware }, async (req, reply) => {
    const result = await query(
      `SELECT rc.*, p.name as project_name, p.entity_type,
              cc.grade, cc.methodology
       FROM retirement_certificates rc
       JOIN carbon_credits cc ON cc.id = rc.credit_id
       JOIN projects p ON p.id = cc.project_id
       WHERE rc.retiring_user_id = $1
       ORDER BY rc.retired_at DESC`,
      [req.user!.sub]
    );
    return reply.send({ certificates: result.rows });
  });

  // ──────────────────────────────────────────────────
  // DASHBOARD STATS
  // ──────────────────────────────────────────────────
  app.get('/api/v1/dashboard', { preHandler: authMiddleware }, async (req, reply) => {
    const [projects, portfolio, payments, retirements] = await Promise.all([
      query(
        `SELECT COUNT(*) as total,
                SUM(CASE WHEN status IN ('verified','listed','sold') THEN 1 ELSE 0 END) as verified,
                SUM(CASE WHEN status = 'analyzing' THEN 1 ELSE 0 END) as analyzing
         FROM projects WHERE user_id = $1`,
        [req.user!.sub]
      ),
      query(
        `SELECT COALESCE(SUM(up.quantity),0) as total_co2e,
                COALESCE(SUM(up.quantity * ml.unit_price_inr),0) as portfolio_value_inr
         FROM user_portfolio up
         LEFT JOIN marketplace_listings ml ON ml.credit_id = up.credit_id AND ml.status = 'active'
         WHERE up.user_id = $1 AND up.retired_at IS NULL`,
        [req.user!.sub]
      ),
      query(
        `SELECT COALESCE(SUM(amount_inr),0) as total_earned
         FROM payment_intents
         WHERE status = 'succeeded' AND buyer_id != $1`,
        [req.user!.sub]  // earnings from sales
      ),
      query(
        `SELECT COALESCE(SUM(amount_co2e),0) as total_retired
         FROM retirement_certificates WHERE retiring_user_id = $1`,
        [req.user!.sub]
      ),
    ]);

    return reply.send({
      projects: {
        total:     parseInt(projects.rows[0]?.total || '0'),
        verified:  parseInt(projects.rows[0]?.verified || '0'),
        analyzing: parseInt(projects.rows[0]?.analyzing || '0'),
      },
      portfolio: {
        totalCo2e:       parseFloat(portfolio.rows[0]?.total_co2e || '0'),
        portfolioValueInr: parseFloat(portfolio.rows[0]?.portfolio_value_inr || '0'),
      },
      earnings: {
        totalInr: parseFloat(payments.rows[0]?.total_earned || '0'),
      },
      retirements: {
        totalCo2e: parseFloat(retirements.rows[0]?.total_retired || '0'),
      },
    });
  });
}
