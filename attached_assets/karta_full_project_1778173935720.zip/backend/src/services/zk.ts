
export async function generateProof(){
  return { proofHash:'zk_123abc', valid:true };
}
