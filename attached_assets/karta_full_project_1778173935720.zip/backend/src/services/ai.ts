
export async function runAIScoring(data:any){
  return { tonnes: 2.46, confidence: 87 };
}
