
export async function fetchSatelliteData(){
  return { ndvi:[0.3,0.4], confidence:90 };
}
