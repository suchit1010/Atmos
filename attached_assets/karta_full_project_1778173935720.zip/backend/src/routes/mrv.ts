
export async function mrvRoute(req:any, reply:any){
  return { message: 'MRV pipeline working' };
}
