
import Fastify from 'fastify';
const app = Fastify();
app.get('/', async () => ({ status: 'KARTA Backend Running' }));
app.listen({ port: 3000 });
